# Collabflo - Design Responsive Landing Page

This is the code for the Collabflo responsive landing page.

## Running the code

Run `npm i` to install the dependencies.

Run `npm run dev` to start the development server.
